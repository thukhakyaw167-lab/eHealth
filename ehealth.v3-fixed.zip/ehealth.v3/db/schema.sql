
-- eHealth Database Setup (Firebase + PHP Edition)
CREATE DATABASE IF NOT EXISTS ehealth CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ehealth;

-- Users
CREATE TABLE IF NOT EXISTS users (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  firebase_uid VARCHAR(128) NOT NULL,
  email VARCHAR(190) NOT NULL,
  display_name VARCHAR(120) NULL,
  name VARCHAR(120) NULL,         -- NEW
  age INT NULL,                   -- NEW
  address VARCHAR(255) NULL,      -- NEW
  phone VARCHAR(40) NULL,         -- NEW
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_uid (firebase_uid),
  KEY idx_email (email)
);

-- Vitals
CREATE TABLE IF NOT EXISTS vitals (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  firebase_uid VARCHAR(128) NOT NULL,
  sbp SMALLINT,
  dbp SMALLINT,
  hr SMALLINT,
  spo2 SMALLINT,
  temp FLOAT,
  sugar SMALLINT,
  weight FLOAT,
  height FLOAT,
  diet_pref VARCHAR(50) DEFAULT 'none',
  measured_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  KEY idx_uid_time (firebase_uid, measured_at)
);

-- Reminders
CREATE TABLE IF NOT EXISTS reminders (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  firebase_uid VARCHAR(128) NOT NULL,
  title VARCHAR(255),
  time_hhmm VARCHAR(5),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_uid (firebase_uid)
);

-- Subscriptions (for $20/month plan, optional)
CREATE TABLE IF NOT EXISTS subscriptions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  firebase_uid VARCHAR(128) NOT NULL UNIQUE,
  status ENUM('active','trialing','past_due','canceled','incomplete','incomplete_expired','unpaid') DEFAULT 'incomplete',
  stripe_customer_id VARCHAR(120),
  stripe_subscription_id VARCHAR(120),
  current_period_end INT UNSIGNED,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
