<?php
// api/subscription_create.php
header('Content-Type: application/json');
echo json_encode([
  'ok' => true,
  'url' => 'https://example.com/payment' // fake checkout link
]);
