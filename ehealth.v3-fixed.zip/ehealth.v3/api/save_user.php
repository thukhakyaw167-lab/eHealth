
<?php
require_once __DIR__ . '/config.php';

$body  = json_decode(file_get_contents('php://input'), true);
$uid   = $body['uid']     ?? '';
$email = $body['email']   ?? '';
$name  = $body['name']    ?? null;      // display name
$age   = $body['age']     ?? null;
$addr  = $body['address'] ?? null;      // location/address
$phone = $body['phone']   ?? null;

if (!$uid) json_out(['ok'=>false,'message'=>'uid required'], 400);

try {
  $pdo = db();
  $sql = "INSERT INTO users (firebase_uid, email, display_name, name, age, address, phone)
          VALUES (:uid,:email,:dname,:name,:age,:addr,:phone)
          ON DUPLICATE KEY UPDATE
            email=VALUES(email), display_name=VALUES(display_name),
            name=VALUES(name), age=VALUES(age),
            address=VALUES(address), phone=VALUES(phone)";
  $st = $pdo->prepare($sql);
  $st->execute([
    ':uid'=>$uid, ':email'=>$email, ':dname'=>$name,
    ':name'=>$name, ':age'=>$age, ':addr'=>$addr, ':phone'=>$phone
  ]);
  json_out(['ok'=>true]);
} catch (Exception $e) {
  json_out(['ok'=>false,'message'=>$e->getMessage()], 500);
}
?>
