
<?php
// api/ai_chat.php

// ✅ Always return JSON + allow CORS from Firebase hosting
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: https://ehealth-956ab.web.app');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  http_response_code(204);
  exit;
}

require_once __DIR__ . '/config.php';

$data = json_decode(file_get_contents('php://input'), true);
$msg = $data['message'] ?? '';
$uid = $data['uid'] ?? '';

if (!$msg) {
  echo json_encode(['ok' => false, 'error' => 'Empty message']);
  exit;
}

// 🔑 Put your OpenAI API key here (keep it secret!)
$apiKey = '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';
$url = 'https://api.openai.com/v1/chat/completions';

// ✅ Build OpenAI request
$body = [
  'model' => 'gpt-4o-mini',  // lighter, faster
  'messages' => [
    ['role' => 'system', 'content' => 'You are a friendly AI health assistant. Answer short and clearly.'],
    ['role' => 'user', 'content' => $msg]
  ],
  'temperature' => 0.7
];

// ✅ Send request safely
$ch = curl_init($url);
curl_setopt_array($ch, [
  CURLOPT_HTTPHEADER => [
    'Content-Type: application/json',
    'Authorization: Bearer ' . $apiKey
  ],
  CURLOPT_POST => true,
  CURLOPT_POSTFIELDS => json_encode($body),
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_TIMEOUT => 20
]);
$res = curl_exec($ch);
$err = curl_error($ch);
curl_close($ch);

if ($err) {
  echo json_encode(['ok' => false, 'error' => 'cURL error: ' . $err]);
  exit;
}

// ✅ Parse response
$json = json_decode($res, true);
if (!isset($json['choices'][0]['message']['content'])) {
  echo json_encode(['ok' => false, 'error' => 'Invalid OpenAI response', 'raw' => $res]);
  exit;
}

$reply = $json['choices'][0]['message']['content'];
echo json_encode(['ok' => true, 'reply' => $reply]);
