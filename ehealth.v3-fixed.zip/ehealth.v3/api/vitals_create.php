
<?php
// api/vitals_create.php — insert a vitals row
require_once __DIR__ . '/config.php';

$body = json_decode(file_get_contents('php://input'), true);
$uid = $body['uid'] ?? '';

if (!$uid) json_out(['ok'=>false, 'message'=>'uid required'], 400);

try {
  $pdo = db();
  $stmt = $pdo->prepare('
    INSERT INTO vitals (firebase_uid, sbp, dbp, hr, spo2, temp, sugar, weight, height, diet_pref, measured_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  ');
  $stmt->execute([
    $uid,
    intval($body['sbp'] ?? 0),
    intval($body['dbp'] ?? 0),
    intval($body['hr']  ?? 0),
    intval($body['spo2']?? 0),
    isset($body['temp'])  ? floatval($body['temp'])  : null,
    isset($body['sugar']) ? intval($body['sugar'])   : null,
    isset($body['weight'])? floatval($body['weight']): null,
    isset($body['height'])? floatval($body['height']): null,
    $body['dietPref'] ?? 'none',
    !empty($body['measuredAt']) ? $body['measuredAt'] : date('Y-m-d H:i:s')
  ]);
  json_out(['ok'=>true]);
} catch (Exception $e) {
  json_out(['ok'=>false, 'message'=>$e->getMessage()], 500);
}
?>
