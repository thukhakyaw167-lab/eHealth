
<?php
// api/reminders_delete.php — delete reminder
require_once __DIR__ . '/config.php';

$uid = $_GET['uid'] ?? '';
$id  = intval($_GET['id'] ?? 0);

if (!$uid || !$id) json_out(['ok'=>false, 'message'=>'uid and id required'], 400);

try {
  $pdo = db();
  $stmt = $pdo->prepare('DELETE FROM reminders WHERE id = ? AND firebase_uid = ?');
  $stmt->execute([$id, $uid]);
  json_out(['ok'=>true]);
} catch (Exception $e) {
  json_out(['ok'=>false, 'message'=>$e->getMessage()], 500);
}
?>
