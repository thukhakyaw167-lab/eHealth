
<?php
// api/vitals_list.php — latest 50
require_once __DIR__ . '/config.php';

$uid = $_GET['uid'] ?? '';
if (!$uid) json_out(['ok'=>false, 'message'=>'uid required'], 400);

try {
  $pdo = db();
  $stmt = $pdo->prepare('SELECT * FROM vitals WHERE firebase_uid = ? ORDER BY measured_at DESC LIMIT 50');
  $stmt->execute([$uid]);
  $rows = $stmt->fetchAll();
  json_out(['ok'=>true, 'items'=>$rows]);
} catch (Exception $e) {
  json_out(['ok'=>false, 'message'=>$e->getMessage()], 500);
}
?>
