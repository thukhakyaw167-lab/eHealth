<?php
// OpenAI API Key
$OPENAI_API_KEY = "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";
?>