
<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json');

$uid = $_GET['uid'] ?? '';
if (!$uid) json_out(['ok'=>false,'error'=>'uid required'], 400);

$pdo = db();
$st = $pdo->prepare("SELECT sbp,dbp,hr,spo2,temp,sugar,measured_at
                     FROM vitals WHERE firebase_uid=? ORDER BY measured_at DESC LIMIT 2");
$st->execute([$uid]);
$rows = $st->fetchAll();

if (!$rows) json_out(['ok'=>true,'today'=>null,'yesterday'=>null,'diff'=>null]);

$today = $rows[0];
$yest  = $rows[1] ?? null;

$diff = null;
if ($yest) {
  $diff = [
    'sbp'   => (int)$today['sbp']   - (int)$yest['sbp'],
    'dbp'   => (int)$today['dbp']   - (int)$yest['dbp'],
    'hr'    => (int)$today['hr']    - (int)$yest['hr'],
    'spo2'  => (int)$today['spo2']  - (int)$yest['spo2'],
    'temp'  => (float)$today['temp']- (float)$yest['temp'],
    'sugar' => (int)$today['sugar'] - (int)$yest['sugar'],
  ];
}
json_out(['ok'=>true,'today'=>$today,'yesterday'=>$yest,'diff'=>$diff]);
?>
