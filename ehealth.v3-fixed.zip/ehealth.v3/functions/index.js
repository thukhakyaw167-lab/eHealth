const functions = require("firebase-functions");
const axios = require("axios");

exports.ai_chat = functions.https.onRequest(async (req, res) => {
  res.set("Access-Control-Allow-Origin", "*");
  res.set("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    res.status(204).send("");
    return;
  }

  try {
    const { message, uid } = req.body;
    if (!message) {
      res.json({ ok: false, error: "Empty message" });
      return;
    }

    const apiKey = "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";
    const response = await axios.post(
      "https://api.openai.com/v1/chat/completions",
      {
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: "You are an AI health assistant." },
          { role: "user", content: message },
        ],
        temperature: 0.7,
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
      }
    );

    const reply = response.data.choices[0].message.content;
    res.json({ ok: true, reply });
  } catch (error) {
    console.error("AI error:", error);
    res.json({ ok: false, error: "AI request failed" });
  }
});
