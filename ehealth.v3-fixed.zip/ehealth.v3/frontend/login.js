
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

const loginForm = document.getElementById('loginForm');
const regForm   = document.getElementById('regForm');
const msg       = document.getElementById('msg');

document.getElementById('showReg').onclick = (e)=>{
  e.preventDefault(); loginForm.classList.add('hidden'); regForm.classList.remove('hidden'); msg.classList.add('hidden');
};
document.getElementById('showLogin').onclick = (e)=>{
  e.preventDefault(); regForm.classList.add('hidden'); loginForm.classList.remove('hidden'); msg.classList.add('hidden');
};

function toast(ok, text){
  msg.className = 'msg';
  msg.style.color = ok ? '#155e75' : '#7f1d1d';
  msg.textContent = text;
  msg.classList.remove('hidden');
}

// LOGIN
loginForm.addEventListener('submit', async (e)=>{
  e.preventDefault();
  try{
    const {user} = await auth.signInWithEmailAndPassword(email.value, password.value);
    localStorage.setItem('uid', user.uid);
    localStorage.setItem('email', user.email || '');
    location.href = 'home.html';
  }catch(err){ toast(false, err.message || 'Login failed'); }
});

// REGISTER (with name/age/address/phone)
regForm.addEventListener('submit', async (e)=>{
  e.preventDefault();
  try{
    const {user} = await auth.createUserWithEmailAndPassword(remail.value, rpass.value);
    await user.updateProfile({ displayName: rname.value });
    // Save extended profile to MySQL
    await fetch('../api/save_user.php', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({
        uid:user.uid, email:user.email, name:rname.value,
        age: rage.value ? +rage.value : null,
        address: raddr.value || null,
        phone: rphone.value || null
      })
    });
    toast(true, 'Account created. Please log in.');
    regForm.classList.add('hidden'); loginForm.classList.remove('hidden');
  }catch(err){ toast(false, err.message || 'Registration failed'); }
});
