// 🧠 eHealth AI Chat API (Firebase Cloud Function)
const AI_URL ="https://us-central1-ehealth-956ab.cloudfunctions.net/ai_chat"; // deploy





// 🩺 PHP API base URL (replace with your actual backend URL if hosted separately)
const PHP_API = "http://localhost/ehealth/api";

// frontend/home.js — main script
(() => {
  'use strict';

  // ===== 0) Auth & user =====
  const UID   = localStorage.getItem('uid');
  const EMAIL = localStorage.getItem('email') || '';
  if (!UID) { location.href = 'login.html'; return; }

  const $ = (id) => document.getElementById(id);
  const setText = (id, txt) => { const el = $(id); if (el) el.textContent = txt; };

  setText('userName', (EMAIL.split('@')[0] || 'Friend'));
  const logoutBtn = $('logout');
  if (logoutBtn) logoutBtn.onclick = () => { localStorage.clear(); location.href = 'login.html'; };

  // ===== 1) DOM refs =====
  const urgent        = $('urgent');
  const riskSummary   = $('riskSummary');
  const mealPlan      = $('mealPlan');
  const historyWrap   = $('history');
  const historyEmpty  = $('historyEmpty');
  const cmpWrap       = $('cmp');
  const adviceBtns    = $('adviceBtns');
  const adviceOut     = $('adviceOut');

  // ===== Helper for API fetch with JSON check =====
  async function apiFetch(url, opts = {}) {
    const r = await fetch(url, opts);
    const text = await r.text();
    try { return JSON.parse(text); }
    catch {
      console.warn("⚠️ API not valid JSON:", url, text.slice(0, 100));
      return { ok: false, error: "Invalid JSON response" };
    }
  }

  // ===== 2) Daily check =====
  const dailyBtn = $('btnDaily');
  if (dailyBtn) {
    dailyBtn.onclick = () => {
      const hasHead = $('chkHeadache')?.checked;
      const hasDiz  = $('chkDizzy')?.checked;
      const hasFever= $('chkFever')?.checked;
      const hasCough= $('chkCough')?.checked;
      const tips = [];
      if (hasHead) tips.push('Drink water, rest eyes, avoid late caffeine.');
      if (hasDiz)  tips.push('Stand slowly, hydrate, check BP if possible.');
      if (hasFever)tips.push('Hydrate, light meals; see clinic if >38.5°C persists.');
      if (hasCough)tips.push('Warm fluids; see clinic if severe/long.');
      $('dailyOut').textContent = tips.length ? tips.join(' ') : 'All good today. Keep moving and eat balanced.';
    };
  }

  // ===== 3) Advice buttons =====
  const ADVICE = [
    {label:'Headache', text:'Hydrate; potassium-rich foods. Avoid excessive caffeine.', foods:['Banana','Leafy greens','Oats']},
    {label:'Dizziness', text:'Check BP; add fluids/electrolytes. Move slowly from sitting.', foods:['Water','Electrolyte drink','Broth']},
    {label:'Fatigue', text:'Sleep enough; iron + vitamin C together helps.', foods:['Spinach','Lentils','Citrus']},
    {label:'Short of breath', text:'If persistent/severe, seek medical care.', foods:['Spinach','Tofu','Citrus']}
  ];
  if (adviceBtns) {
    ADVICE.forEach(a => {
      const b = document.createElement('button');
      b.className = 'btn btn--ghost';
      b.textContent = a.label;
      b.onclick = () => {
        adviceOut.innerHTML = `<b>${a.label}:</b> ${a.text}<br><span class='small'>Foods: ${a.foods.join(', ')}</span>`;
      };
      adviceBtns.appendChild(b);
    });
  }

  // ===== 4) Save vitals =====
  const vitalsForm = $('vitalsForm');
  if (vitalsForm) {
    vitalsForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const sbp = +($('sbp')?.value || 0);
      const dbp = +($('dbp')?.value || 0);
      const hr  = +($('hr')?.value  || 0);
      const spo2= +($('spo2')?.value|| 0);
      const temp  = $('temp')?.value ? +$('temp').value : null;
      const sugar = $('sugar')?.value? +$('sugar').value: null;
      const weight = $('weight')?.value? +$('weight').value: null;
      const height = $('height')?.value? +$('height').value: null;
      const dietPref = $('dietPref')?.value || 'none';

      const payload = { uid: UID, sbp, dbp, hr, spo2, temp, sugar, weight, height, dietPref };

      if (weight && height) {
        const bmi = weight / ((height/100)**2);
        setText('bmiOut', 'BMI ' + bmi.toFixed(1));
      }

      if ((sbp>=180 || dbp>=120 || spo2<90) && urgent) {
        urgent.classList.remove('hidden');
        urgent.textContent = '⚠️ Danger zone. Seek medical advice.';
      } else { urgent?.classList.add('hidden'); }

      if (riskSummary) {
        riskSummary.innerHTML = '';
        const risks = [];
        if (sbp>=130 || dbp>=80) risks.push('High BP → low sodium');
        if (hr>100) risks.push('High HR → hydrate, avoid stimulants');
        if (spo2<95) risks.push('Low SpO₂ → iron + vitamin C');
        risks.forEach(r => {
          const x = document.createElement('span');
          x.className = 'badge';
          x.textContent = r;
          riskSummary.appendChild(x);
        });
      }

      const res = await apiFetch(`${PHP_API}/vitals_create.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (res.ok) { loadHistory(); loadCompare(); }
    });
  }

  // ===== 5) History =====
  async function loadHistory() {
    const d = await apiFetch(`${PHP_API}/vitals_list.php?uid=${encodeURIComponent(UID)}`);
    if (!d.ok) return console.warn('History failed:', d.error);
    const items = d.items || [];
    if (!historyWrap) return;
    historyWrap.innerHTML = '';
    if (!items.length) {
      historyEmpty?.classList.remove('hidden'); return;
    }
    historyEmpty?.classList.add('hidden');

    items.slice(0,12).forEach(it => {
      const div = document.createElement('div');
      div.className = 'hcard';
      div.innerHTML = `<div class="hhead"><span>${it.measured_at}</span><span>${it.sbp}/${it.dbp} • ${it.hr}bpm • ${it.spo2}%</span></div>`;
      historyWrap.appendChild(div);
    });
  }
  loadHistory();

  // ===== 6) Compare =====
  async function loadCompare(){
    const d = await apiFetch(`${PHP_API}/compare_get.php?uid=${encodeURIComponent(UID)}`);
    if (!d.ok || !d.diff) { cmpWrap.textContent = 'Need at least 2 entries.'; return; }
    cmpWrap.innerHTML = '';
    const map = {sbp:'SBP', dbp:'DBP', hr:'HR', spo2:'SpO₂', temp:'Temp', sugar:'Sugar'};
    Object.keys(map).forEach(k=>{
      const v = d.diff[k];
      const span = document.createElement('span');
      span.className = 'badge';
      const sign = v>0?'+':'';
      span.textContent = `${map[k]} ${sign}${v}`;
      cmpWrap.appendChild(span);
    });
  }
  loadCompare();

  // ===== 7) AI Assistant =====
  const chatBox = $('chatBox');
  const chatInput = $('chatInput');
  const sendChat = $('sendChat');
  if (sendChat && chatBox && chatInput) {
    sendChat.onclick = async () => {
      const m = chatInput.value.trim();
      if (!m) return;
      chatBox.innerHTML += `<div class="hcard">🧍 ${m}</div>`;
      chatInput.value = '';
      try {
        const resp = await fetch(AI_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ message: m, uid: UID })
        });
        const j = await resp.json();
        chatBox.innerHTML += `<div class="hcard">${j.ok ? '🤖 '+j.reply : '⚠️ '+(j.error||'AI not configured')}</div>`;
      } catch(e) {
        chatBox.innerHTML += `<div class="hcard">⚠️ AI unavailable</div>`;
      }
    };
  }

  // ===== 8) Nearby hospitals =====
  const nearBtn = $('nearbyHospitals');
  if (nearBtn) nearBtn.onclick = () => {
    window.open('https://www.google.com/maps/search/hospitals near me','_blank');
  };

})();
