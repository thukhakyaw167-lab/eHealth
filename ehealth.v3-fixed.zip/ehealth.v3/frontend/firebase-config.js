const firebaseConfig = {
  apiKey: "AIzaSyCUhXf0fCSM-9GI_DMblHsG9I2eG6syyr0",
  authDomain: "ehealth-956ab.firebaseapp.com",
  projectId: "ehealth-956ab",
  storageBucket: "ehealth-956ab.firebasestorage.app",
  messagingSenderId: "975151254629",
  appId: "1:975151254629:web:2fd833a8c5bfc544f64a8c",
  measurementId: "G-Z4G48V3LX7"
};
// Using compat SDK; initialization happens in login.js
