
# eHealth — Firebase + PHP + MySQL (V2, formatted, full UI)

## Setup
1) MySQL ▶ run `db/schema.sql` (creates DB `ehealth` and tables).
2) Edit `api/config.php` → set your local DB user/password.
3) Firebase Console ▶ create project → enable **Email/Password** sign-in.
   - Copy keys to `frontend/firebase-config.js`.
4) Put this folder into your local server root (e.g., `C:/xampp/htdocs/ehealth/`).
5) Open: `http://localhost/ehealth/frontend/login.html`

- Login & Register uses Firebase (no server login → zero CORS/network error).
- Vitals/Reminders use PHP endpoints on **same origin** (`../api/...`) → CORS-free.
- Home UI: BMI, risk chips, meals, history cards, line charts, reminders.

## Notes
- Demo trusts client `uid`. For production, validate Firebase ID token on server.
- You can seed `vitals` manually for charts if empty.
